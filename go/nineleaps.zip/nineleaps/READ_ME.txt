**********************************************
Sample Database
**********************************************

Mysql database is used as database for the application.

Import database  "employeeDetails.sql" from nineleaps.zip

Change user credentials in ndbConnect.php (used to connect to the database). 

**********************************************
Source Code Files :
**********************************************

index.html
ied.html
wrong.html
right.html
displayTable.php
ndbConnect.php
form.css
button.css
listView.php
listView1.php

**********************************************
Dependencies( Languages / Database) :
**********************************************

1. mysql

{

OUTPUT OF mysql --version ON MY COMPUTER :

mysql  Ver 14.14 Distrib 5.5.53, for debian-linux-gnu (x86_64) using readline 6.3

}

2. php

{

OUTPUT OF php --version ON MY COMPUTER :

(PHP 5.5.9-1ubuntu4.20 (cli) (built: Oct  3 2016 13:00:37))

}

3. HTML

4. CSS

5. Java Script

6. phpmyadmin



**********************************************
STEPS TO RUN SERVER :
**********************************************

Application has been tested on locally hosted LAMP server.

Extract the nineleaps.zip zipfile in your computers localhost folder.

Import the databse employeeDetails.sql

Change user credentials (PASSWORD and  USERNAME) in ndbConnect.php (Used to connect to the database.).

Go to URL :  localhost/nineleaps/index.html

**********************************************

	
Contact Information :

shivam21413.cse@mietjammu.in
8803138841 (Watsapp)


